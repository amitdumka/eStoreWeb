﻿SET IDENTITY_INSERT [dbo].[Suppliers] ON
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (1, N'Aprajita Retails - Jamshedpur', N'Aprajita Retails - Jamshedpur', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (2, N'Arvind Brands Limited', N'Arvind Brands Limited', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (3, N'Arvind Limited', N'Arvind Limited', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (4, N'Bangalore WH', N'Bangalore WH', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (5, N'DTR - TAS Warehouse', N'DTR - TAS Warehouse', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (6, N'DTR Packed WH', N'DTR Packed WH', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (7, N'Khush', N'Khush', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (8, N'Safari Industries India Ltd', N'Safari Industries India Ltd', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (9, N'TAS - Warhouse -FOFO', N'TAS - Warhouse -FOFO', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (10, N'TAS RMG Warehouse - Bangalore', N'TAS RMG Warehouse - Bangalore', NULL)
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SuppilerName], [Warehouse], [LocationCode]) VALUES (11, N'TAS RTS - Warhouse', N'TAS RTS - Warhouse', NULL)
SET IDENTITY_INSERT [dbo].[Suppliers] OFF
