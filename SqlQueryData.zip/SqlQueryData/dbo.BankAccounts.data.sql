﻿SET IDENTITY_INSERT [dbo].[BankAccounts] ON
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (1, 1, N'SBI_CC-37604947464', N'LIC Dumka', 2)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (2, 2, N'ICICI Saving-063001502791', N'Dumka', 0)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (3, 5, N'AmitKumar_BOB	-31310100005502', N'Dumka', 0)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (5, 4, N'AmitKumar_PNB-4492000100013840', N'Dumka', 0)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (6, 2, N'AprajitaRetails_ICICI-63005500372', N'Dumka', 1)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (7, 2, N'Shalini_ICICI-063001504395', N'Dumka', 0)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (8, 7, N'HDFC_CA-50200006818376', N'Dumka', 1)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (9, 3, N'Bandhan_CurrentAcc-10170001063385', N'Dumka', 1)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (11, 1, N'SBI_OD-37604947464', N'LIC Dumka', 3)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (12, 14, N'IDBI_CA-1257102000002230', N'Dumka', 1)
INSERT INTO [dbo].[BankAccounts] ([BankAccountId], [BankId], [Account], [BranchName], [AccountType]) VALUES (13, 1, N'SBI_Current-35130948344', N'LIC Dumka', 1)
SET IDENTITY_INSERT [dbo].[BankAccounts] OFF
